<?php
defined('BASEPATH') or exit('No direct script access allowed');

if (!function_exists('infoLogin')) {
    function infoLogin()
    {
        $ci = &get_instance();
        
        // Pastikan session sudah di-load
        $ci->load->library('session');
        
        // Ambil data user yang login dari session
        $userdata = array(
            'user_id' => $ci->session->userdata('user_id'),
            'username' => $ci->session->userdata('username'),
            'name' => $ci->session->userdata('name'),
            'level' => $ci->session->userdata('level'),
            'is_login' => $ci->session->userdata('is_login')
        );
        
        return $userdata;
    }
}